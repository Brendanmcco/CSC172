Brendan McCollum
bmccoll3@u.rochester.edu

PROJECT DESCRIPTION:

In this project, we created a huffman encoding class which can take a file as input, encode it using character frequency and huffman codes, decode the encoded file, and save it to a new file which can then be viewed. One of our methods of interest are .encode, which encodes a given file and creates a .enc file with the endoded data and a .txt file with each character and its frequency. The other method of interest is .decode, which takes a .enc file and that files frequency file as input, and outputs any file type which contains the decoded data from the .enc file.

INSTRUCTIONS:

The user should use the main method to input files to be encoded/decoded. Examples of calls to the encode and decode methods are:

huffman.encode("ur.jpg", "ur.enc", "freq.txt");
huffman.decode("ur.enc", "ur_dec.jpg", "freq.txt");

The code displayed above will be included in the submitted code, but can easily be commented out or edited if the user wants to test their own files. The program will only be able to locate file which exist inside of the eclipse package. Additionally, the program can encode multiple files at a time, and the call to the decode method is independent from the call to the encode method, so .enc files can be decoded whenever the user wants.
